# Banco X — Parte 1 — Login — versão dos alunos

## Abrir a página no Chrome

Extraia o ZIP e abra `src/main/resources/login.html` no Chrome. O HTML já contém o estilo e o JavaScript da simulação.

Para a demonstração manual, digite `Arthur` e `Zane123`, clique em **Entrar** e confira **Login realizado!**. Depois, tente outra senha e observe a mensagem de erro.

## Rodar no Eclipse

1. Use **File → Import → Maven → Existing Maven Projects**.
2. Selecione a pasta `BancoX-Login-Alunos` que contém o `pom.xml` e conclua a importação. Use JDK 17 ou superior e Google Chrome. A primeira execução pode precisar de internet para as dependências e o ChromeDriver.
3. Em **src/test/java → aula.bancox**, clique com o botão direito em `LoginTest.java` e selecione **Run As → JUnit Test**. Com Maven disponível no terminal, você também pode usar `mvn test` na raiz do projeto.

O Selenium abre o Chrome e repete as ações na página. O JUnit compara os resultados e mostra o relatório. Cada teste ativo recebe uma nova sessão do navegador.

## Parte 1 — Complete os testes de login

1. Use `deveEntrarComoArthur()` como modelo. O exemplo pronto usa `Arthur` e `Zane123`.
2. Complete o segundo e o terceiro cenários com os pares apresentados nos slides. Em cada um, confira **Login realizado!** e o nome na conta.
3. No caso inválido, use o usuário `Arthur` com a senha `Mon123`. Confira **Usuário ou senha inválidos** e verifique que a área da conta está escondida. O teste passa quando confirma a recusa do login.

| ID | Elemento que o Selenium procura |
| --- | --- |
| `usuario`, `senha`, `entrar` | Os campos do formulário e o botão de login. |
| `mensagem` | Texto de sucesso ou erro do login. |
| `cliente` | Nome que aparece na conta. |
| `conta` | Área exibida depois de um login válido. `isDisplayed()` informa se está visível. |

O teste do Arthur já vem pronto. Os outros três começam desativados. Ao completar um método, remova a linha `fail(...)` e a anotação `@Disabled`. Rode `LoginTest.java` e entregue o código e um print da aba JUnit.
