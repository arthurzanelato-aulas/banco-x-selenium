package aula.bancox;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;

class LoginTest extends TesteBanco {

    @Test
    void deveEntrarComoArthur() {
        fazerLogin("Arthur", "Zane123");

        String mensagem = navegador.findElement(By.id("mensagem")).getText();
        String cliente = navegador.findElement(By.id("cliente")).getText();
        assertEquals("Login realizado!", mensagem);
        assertEquals("Arthur", cliente);
    }

    @Disabled("Complete o segundo caso de login válido")
    @Test
    void deveEntrarComSegundoLoginValido() {
        fail("Complete o segundo cenário e remova esta linha.");
    }

    @Disabled("Complete o terceiro caso de login válido")
    @Test
    void deveEntrarComTerceiroLoginValido() {
        fail("Complete o terceiro cenário e remova esta linha.");
    }

    @Disabled("Complete o caso de login inválido")
    @Test
    void deveRejeitarLoginInvalido() {
        fail("Complete o cenário inválido e remova esta linha.");
    }
}
