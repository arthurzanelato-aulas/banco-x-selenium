package aula.bancox;

import java.net.URL;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

abstract class TesteBanco {

    protected WebDriver navegador;

    @BeforeEach
    void abrirBanco() {
        URL pagina = TesteBanco.class.getResource("/login.html");
        navegador = new ChromeDriver();
        navegador.get(pagina.toExternalForm());
    }

    @AfterEach
    void fecharBanco() {
        if (navegador != null) {
            navegador.quit();
        }
    }

    void fazerLogin(String usuario, String senha) {
        navegador.findElement(By.id("usuario")).sendKeys(usuario);
        navegador.findElement(By.id("senha")).sendKeys(senha);
        navegador.findElement(By.id("entrar")).click();
    }
}
