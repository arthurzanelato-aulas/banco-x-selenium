# Banco X — Parte 2 — Operações — versão dos alunos

## Abrir a página no Chrome

Extraia o ZIP e abra `src/main/resources/banco.html` no Chrome. O HTML já contém o estilo e o JavaScript da simulação.

Faça login com `Arthur` e `Zane123`. A página mostra o saldo inicial de **R$ 500,00** e os formulários de saque e transferência. Pra começar uma demonstração nova com os saldos iniciais, recarregue o HTML.

## Rodar no Eclipse

1. Use **File → Import → Maven → Existing Maven Projects**.
2. Selecione a pasta `BancoX-Operacoes-Alunos` que contém o `pom.xml` e conclua a importação. Use JDK 17 ou superior e Google Chrome. A primeira execução pode precisar de internet para as dependências e o ChromeDriver.
3. Em **src/test/java → aula.bancox**, clique com o botão direito em `OperacoesBancoTest.java` e selecione **Run As → JUnit Test**. Com Maven disponível no terminal, você também pode usar `mvn test` na raiz do projeto.

O Selenium abre o Chrome e repete as ações na página. O JUnit compara os resultados e mostra o relatório. Cada teste ativo recebe uma nova sessão do navegador.

## Parte 2 — Complete os testes de operações

Abra `OperacoesBancoTest.java`. A preparação já entra na conta de Arthur e confere o saldo inicial de **R$ 500,00** em cada teste.

- **Exemplo pronto.** Execute `deveAtualizarSaldoAposSaqueDe150()`. O teste saca R$ 150,00 e verifica a mensagem **Saque realizado!** e o saldo de **R$ 350,00**.
- **Exercício obrigatório.** Complete `deveAtualizarSaldoAposSaqueDe80()`. Saque R$ 80,00, calcule o saldo esperado e confira o saldo e a mensagem **Saque realizado!** no JUnit.
- **Desafio extra.** Transfira R$ 150,00 de Arthur para Larissa. Confira a mensagem **Transferência realizada!** e o saldo calculado de Arthur. Para conferir também o saldo de Larissa, use **Sair** e entre na conta dela na mesma página.

| ID | Elemento que o Selenium procura |
| --- | --- |
| `valor-saque`, `sacar` | Campo do valor e botão de saque. |
| `destinatario` | Lista de clientes. Use `Select` do Selenium com `selectByVisibleText(...)`. |
| `valor-transferencia`, `transferir` | Campo do valor e botão de transferência. |
| `saldo` | Saldo exibido. O formato é `R$ 500,00`. |
| `mensagem-operacao`, `sair` | Mensagem da operação e botão de sair. |

O exemplo já está habilitado. O saque de R$ 80,00 e a transferência começam desativados. Ao completar um método, remova a linha `fail(...)` e a anotação `@Disabled`. Rode `OperacoesBancoTest.java` e entregue o código e um print da aba JUnit.

Para o desafio extra, use os dados de login que o professor apresentou na Parte 1.
