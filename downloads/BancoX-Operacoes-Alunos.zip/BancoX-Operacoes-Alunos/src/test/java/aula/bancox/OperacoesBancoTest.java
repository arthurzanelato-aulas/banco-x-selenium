package aula.bancox;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;

class OperacoesBancoTest extends TesteBanco {

    @BeforeEach
    void entrarNaContaDoArthur() {
        fazerLogin("Arthur", "Zane123");
        assertEquals("R$ 500,00", navegador.findElement(By.id("saldo")).getText());
    }

    @Test
    void deveAtualizarSaldoAposSaqueDe150() {
        navegador.findElement(By.id("valor-saque")).sendKeys("150");
        navegador.findElement(By.id("sacar")).click();

        assertEquals("Saque realizado!", navegador.findElement(By.id("mensagem-operacao")).getText());
        assertEquals("R$ 350,00", navegador.findElement(By.id("saldo")).getText());
    }

    @Disabled("Complete o teste de saque de R$ 80,00")
    @Test
    void deveAtualizarSaldoAposSaqueDe80() {
        fail("Complete o cenário de saque e remova esta linha.");
    }

    @Disabled("Desafio extra de transferência")
    @Test
    void deveAtualizarSaldosAposTransferencia() {
        fail("Complete o cenário de transferência e remova esta linha.");
    }
}
